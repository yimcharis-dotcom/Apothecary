---
date: {{date}}
project: {{project}}
ai_model: {{model}}
review_type: {{type}}
tags: #review #{{project}}
---

# Review: {{title}}

## 📋 Review Summary
**Date:** {{date}}
**AI Model:** {{model}}
**Prompt Version:** {{version}}

## ✅ Quality Metrics

### Accuracy (/10)
- ✓ 
- ⚠ 

### Completeness (/10)
- ✓ 
- ⚠ 

### Actionability (/10)
- ✓ 
- ⚠ 

## 🔄 Improvement Areas

### Critical Issues
1. 

### Minor Issues
1. 

## 📝 Iteration Notes

### Next Version Changes
```
```

### Test Cases
- [ ] 

## 📊 Comparison
| Version | Accuracy | Completeness | Actionability | Overall |
|---------|----------|--------------|---------------|---------|

## 🎯 Action Items
- [ ] 

## 🔗 Related
- 
