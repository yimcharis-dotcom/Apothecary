---
date: {{date}}
time: {{time}}
project: {{project}}
ai_model: {{model}}
tags: #ai-interaction #{{project}}
---

# AI Interaction - {{title}}

## 🎯 Objective
{{objective}}

## 💬 Prompt
```
{{prompt}}
```

## 🤖 Response
```
{{response}}
```

## ✅ Quality Check
- [ ] Meets requirements
- [ ] Technically accurate
- [ ] Complete
- [ ] Actionable

## 🔄 Iteration Notes
**Improvements:**
- 

**Next version changes:**
- 

## 📊 Evaluation
- **Accuracy:** /10
- **Completeness:** /10
- **Actionability:** /10
- **Overall:** /10

## 🔗 Related
- 
