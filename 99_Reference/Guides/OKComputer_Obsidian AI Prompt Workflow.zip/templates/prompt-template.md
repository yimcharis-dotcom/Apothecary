---
category: {{category}}
model: {{model}}
tags: #prompt #{{category}}
version: 1.0
tested: {{date}}
---

# Prompt: {{title}}

## 🎯 Purpose
{{purpose}}

## 📝 Prompt Template
```
{{prompt_template}}
```

## 🧪 Variables
{{variables}}

## 💡 Example Usage
```
{{example}}
```

## 🔧 Parameters
- **Temperature:** 
- **Max Tokens:** 
- **Top P:** 

## ✅ Quality Checklist
- [ ] 

## 🔄 Iteration History
- v1.0: Initial version

## 📊 Performance
- **Success Rate:** %
- **Avg Quality Score:** /10

## 🔗 Related Prompts
- 
