---
type: session-log
project: "[[{{VALUE:Project name}}]]"
date: {{DATE:YYYY-MM-DD}}
session: {{VALUE:Session number}}
tools: [{{VALUE:Tools used (cursor, antigravity, vscode)}}]
tags:
  - vibe-coding
  - session-log
---

# Session {{VALUE:Session number}} — {{DATE:MMMM DD, YYYY}}

## What I Built
- {{VALUE:What did you build this session?}}

## Decisions Made

| Decision | Rationale | Alternatives Considered |
|----------|-----------|------------------------|
|  |  |  |

## Architecture Changes


## Prompts That Worked
> 

## Issues Encountered
- 

## Tech Debt Introduced
- [ ] 

## Next Session
- [ ] 

## Files Changed

