# ============================================================================
# WatchHub_Realtime.ps1
# Real-time FileSystemWatcher for AI Hub
# Instantly detects new AI tools and auto-links them
# ============================================================================

param(
    [string]$HubPath = "C:\Users\YC\AI_hub",
    [switch]$Verbose
)

# ============================================================================
# Configuration
# ============================================================================

$monitorPaths = @{
    "UserHome" = @{
        Path = "C:\Users\YC"
        Category = "User_Dot"
        Pattern = "^\."  # Folders starting with .
    }
    "AppDataRoaming" = @{
        Path = "$env:APPDATA"
        Category = "AppData_Roaming"
        Pattern = ".*"
    }
    "AppDataLocalPrograms" = @{
        Path = "$env:LOCALAPPDATA\Programs"
        Category = "AppData_Local"
        Pattern = ".*"
    }
    "AppDataLocal" = @{
        Path = "$env:LOCALAPPDATA"
        Category = "AppData_Local"
        Pattern = ".*"
    }
    "GitHubRepo" = @{
        Path = "C:\GitHubRepo"
        Category = "Projects_GitHubRepo"
        Pattern = ".*"
    }
    "RootDot" = @{
        Path = "C:\"
        Category = "Root_Dot"
        Pattern = "^\."
    }
}

# Keywords to identify AI tools
$aiKeywords = @(
    'claude', 'cursor', 'zed', 'ollama', 'gemini', 'windsurf', 
    'mcp', 'anthropic', 'openai', 'copilot', 'codeium', 
    'tabnine', 'github', 'llm', 'ai', 'gpt', 'chatbot',
    'agent', 'aider', 'continue', 'cody', 'supermaven'
)

# File signatures that indicate AI tools
$fileSignatures = @{
    Binary = @('claude.exe', 'cursor.exe', 'zed.exe', 'ollama.exe', 'windsurf.exe')
    Config = @('.cursorrules', '.windsurfrules', 'mcp.json', 'modelfile', 'claude_desktop_config.json')
}

# ============================================================================
# Helper Functions
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    $timestamp = Get-Date -Format "HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

function Test-AITool {
    param(
        [string]$FolderName,
        [string]$FullPath
    )
    
    # Check if folder name matches AI keywords
    $nameMatch = $aiKeywords | Where-Object { $FolderName -like "*$_*" }
    
    # Check if folder contains signature files
    $signatureMatch = $false
    if (Test-Path $FullPath) {
        foreach ($sig in $fileSignatures.Binary + $fileSignatures.Config) {
            if (Get-ChildItem -Path $FullPath -Filter $sig -ErrorAction SilentlyContinue) {
                $signatureMatch = $true
                break
            }
        }
    }
    
    return ($nameMatch -or $signatureMatch)
}

function Get-SafeJunctionName {
    param(
        [string]$FolderName,
        [string]$Category
    )
    
    # Remove leading dot
    $cleanName = $FolderName -replace '^\.', ''
    
    # Create junction name
    $junctionName = "${cleanName}_${Category}"
    
    # Sanitize invalid characters
    $junctionName = $junctionName -replace '[<>:"/\\|?*]', '_'
    
    return $junctionName
}

function New-HubJunction {
    param(
        [string]$SourcePath,
        [string]$FolderName,
        [string]$Category
    )
    
    try {
        $junctionName = Get-SafeJunctionName -FolderName $FolderName -Category $Category
        $junctionPath = Join-Path $HubPath $junctionName
        
        # Skip if junction already exists
        if (Test-Path $junctionPath) {
            if ($Verbose) {
                Write-Log "  Junction already exists: $junctionName" -Color DarkGray
            }
            return $false
        }
        
        # Create junction
        $result = cmd /c mklink /J "$junctionPath" "$SourcePath" 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "  ✓ Created junction: $junctionName" -Color Green
            
            # Log to file
            $logPath = Join-Path $HubPath "discovery.log"
            $logEntry = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | CREATED | $junctionName | $SourcePath"
            Add-Content -Path $logPath -Value $logEntry
            
            return $true
        } else {
            Write-Log "  ✗ Failed to create junction: $result" -Color Red
            return $false
        }
    } catch {
        Write-Log "  ✗ Error: $_" -Color Red
        return $false
    }
}

function Export-ToObsidian {
    $exportScript = Join-Path $HubPath "ExportToObsidian.ps1"
    if (Test-Path $exportScript) {
        Write-Log "Exporting to Obsidian..." -Color Cyan
        & $exportScript
    }
}

# ============================================================================
# FileSystemWatcher Setup
# ============================================================================

Write-Log "═══════════════════════════════════════════════════════" -Color Cyan
Write-Log "  AI Hub Real-Time Monitor" -Color Cyan
Write-Log "═══════════════════════════════════════════════════════" -Color Cyan
Write-Log ""

$watchers = @()
$watcherCount = 0

foreach ($key in $monitorPaths.Keys) {
    $config = $monitorPaths[$key]
    $path = $config.Path
    
    if (-not (Test-Path $path)) {
        Write-Log "⊗ Skipping (not found): $path" -Color DarkGray
        continue
    }
    
    try {
        $watcher = New-Object System.IO.FileSystemWatcher
        $watcher.Path = $path
        $watcher.IncludeSubdirectories = $false
        $watcher.NotifyFilter = [System.IO.NotifyFilters]::DirectoryName
        
        # Create action scriptblock
        $action = {
            $name = $Event.SourceEventArgs.Name
            $changeType = $Event.SourceEventArgs.ChangeType
            $fullPath = $Event.SourceEventArgs.FullPath
            $category = $Event.MessageData.Category
            $pattern = $Event.MessageData.Pattern
            $hubPath = $Event.MessageData.HubPath
            $verbose = $Event.MessageData.Verbose
            
            # Import helper functions (they need to be in scope)
            function Write-Log {
                param([string]$Message, [string]$Color = "White")
                $timestamp = Get-Date -Format "HH:mm:ss"
                Write-Host "[$timestamp] $Message" -ForegroundColor $Color
            }
            
            # Only process folder creation
            if ($changeType -eq 'Created') {
                Write-Log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Yellow
                Write-Log "NEW FOLDER DETECTED" -Color Yellow
                Write-Log "  Name: $name" -Color White
                Write-Log "  Path: $fullPath" -Color Gray
                Write-Log "  Category: $category" -Color Gray
                
                # Check pattern match
                $patternMatch = $name -match $pattern
                
                # Check AI tool signatures
                $isAITool = $false
                $aiKeywords = @(
                    'claude', 'cursor', 'zed', 'ollama', 'gemini', 'windsurf', 
                    'mcp', 'anthropic', 'openai', 'copilot', 'codeium', 
                    'tabnine', 'github', 'llm', 'ai', 'gpt', 'chatbot',
                    'agent', 'aider', 'continue', 'cody', 'supermaven'
                )
                
                $nameMatch = $aiKeywords | Where-Object { $name -like "*$_*" }
                
                if ($nameMatch -or $patternMatch) {
                    $isAITool = $true
                    Write-Log "  → Identified as AI tool!" -Color Green
                    
                    # Create junction
                    $cleanName = $name -replace '^\.', ''
                    $junctionName = "${cleanName}_${category}"
                    $junctionName = $junctionName -replace '[<>:"/\\|?*]', '_'
                    $junctionPath = Join-Path $hubPath $junctionName
                    
                    if (-not (Test-Path $junctionPath)) {
                        $result = cmd /c mklink /J "$junctionPath" "$fullPath" 2>&1
                        
                        if ($LASTEXITCODE -eq 0) {
                            Write-Log "  ✓ Junction created: $junctionName" -Color Green
                            
                            # Log discovery
                            $logPath = Join-Path $hubPath "discovery.log"
                            $logEntry = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | CREATED | $junctionName | $fullPath"
                            Add-Content -Path $logPath -Value $logEntry
                            
                            # Export to Obsidian
                            $exportScript = Join-Path $hubPath "ExportToObsidian.ps1"
                            if (Test-Path $exportScript) {
                                Write-Log "  → Updating Obsidian inventory..." -Color Cyan
                                & $exportScript
                            }
                        } else {
                            Write-Log "  ✗ Failed to create junction" -Color Red
                        }
                    } else {
                        Write-Log "  ⊙ Junction already exists" -Color DarkGray
                    }
                } else {
                    Write-Log "  ⊙ Not identified as AI tool (skipping)" -Color DarkGray
                }
                Write-Log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Yellow
                Write-Log ""
            }
        }
        
        # Prepare message data for action
        $messageData = @{
            Category = $config.Category
            Pattern = $config.Pattern
            HubPath = $HubPath
            Verbose = $Verbose
        }
        
        # Register event
        $null = Register-ObjectEvent -InputObject $watcher `
            -EventName Created `
            -Action $action `
            -MessageData $messageData
        
        $watcher.EnableRaisingEvents = $true
        $watchers += $watcher
        $watcherCount++
        
        Write-Log "✓ Monitoring: $path" -Color Green
        Write-Log "  Category: $($config.Category)" -Color DarkGray
        
    } catch {
        Write-Log "✗ Failed to monitor $path : $_" -Color Red
    }
}

Write-Log ""
Write-Log "═══════════════════════════════════════════════════════" -Color Cyan
Write-Log "  Monitoring $watcherCount locations" -Color Green
Write-Log "  Press Ctrl+C to stop" -Color Yellow
Write-Log "═══════════════════════════════════════════════════════" -Color Cyan
Write-Log ""

# ============================================================================
# Keep Running
# ============================================================================

try {
    # Infinite loop
    while ($true) {
        Start-Sleep -Seconds 1
    }
} finally {
    # Cleanup on exit
    Write-Log ""
    Write-Log "Shutting down watchers..." -Color Yellow
    
    $watchers | ForEach-Object {
        $_.EnableRaisingEvents = $false
        $_.Dispose()
    }
    
    Get-EventSubscriber | Unregister-Event
    
    Write-Log "Monitoring stopped." -Color Red
}
