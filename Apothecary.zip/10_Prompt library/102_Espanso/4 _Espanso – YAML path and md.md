[Open Espanso base](C:\Users\YC\AppData\Roaming\espanso\match\base.yml)

