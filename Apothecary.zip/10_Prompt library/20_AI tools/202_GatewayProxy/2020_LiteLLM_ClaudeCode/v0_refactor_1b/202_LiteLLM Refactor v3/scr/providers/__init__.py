# Provider discovery adapters for model catalog fetch.

