---
tags: [agent-guidelines, development, automation, powershell]
created: 2025-02-12
---

# Agent Guidelines for LiteLLM Refactor

This repository contains a PowerShell-based LiteLLM proxy management system. Follow these guidelines for all development and maintenance tasks.

## 🛠️ Build & Test Commands

### Proxy Management

- **Start Proxy:** `.\scr\start-proxy.ps1`
- **Stop Proxy:** `Stop-Process -Name litellm -Force`
- **Health Check:** `curl http://localhost:4000/health`

### Testing

- **Run All Tests:** `.\scr\test-claude-code.ps1`
- **Test Specific Model:**

  ```powershell
  curl http://localhost:4000/v1/responses `
    -H "Authorization: Bearer $env:LITELLM_MASTER_KEY" `
    -H "Content-Type: application/json" `
    -d '{ "model": "default", "input": [{"role":"user","content":[{"type":"input_text","text":"Hello"}]}] }'
  ```

- **Verify Cost Tracking:** `.\scr\view-spend.ps1`

### Auto-Sync & Maintenance

- **Manual Sync:** `.\scr\sync-models.ps1`
- **Check Status:** `.\scr\check-sync-status.ps1`
- **Run Subagent Discovery (Preview):** `.\scr\run-subagent-discovery.ps1 -DryRun`
- **Run Subagent Discovery (Apply):** `.\scr\run-subagent-discovery.ps1`

## 📝 Code Style Guidelines

### PowerShell Scripts (`.ps1`)

- **Naming:** Kebab-case (e.g., `view-daily-activity.ps1`)
- **Parameters:** Always use `param()` block at the top
- **Output:** Use `Write-Host` with `-ForegroundColor` for status updates
- **Error Handling:** Use `try { ... } catch { ... }` blocks for external calls
- **Paths:** Use `$PSScriptRoot` or relative paths; avoid hardcoded absolute paths where possible

### Configuration (`config.yaml`)

- **Structure:** Follow LiteLLM schema strictly
- **Model Naming:** Use provider prefix (e.g., `openrouter/`, `xai/`) in `litellm_params`
- **Aliases:** Define friendly names in `router_settings.model_group_alias`
- **Secrets:** Use `os.environ/VARIABLE_NAME` for API keys
- **Master Key:** Use `litellm_settings.master_key: os.environ/LITELLM_MASTER_KEY`
- **Database URL:** Use `general_settings.database_url: os.environ/LITELLM_DATABASE_URL`

### Documentation (`.md`)

- **Frontmatter:** Include `tags` and `created` date
- **Links:** Use Obsidian-style links `[[Page Name]]` where appropriate
- **Snippets:** Use code blocks with language specifiers (e.g., `powershell`, `yaml`)

## 📂 Repository Structure

```
/
├── config.yaml                    # Main proxy configuration
├── AGENTS.md                      # This file
├── *.md                           # Documentation guides
└── scr/                           # PowerShell scripts
    ├── start-*.ps1                # Startup scripts
    ├── view-*.ps1                 # Monitoring scripts
    ├── sync-*.ps1                 # Maintenance scripts
    ├── set-env.ps1                # Environment configuration
    ├── discovery.py               # Legacy OpenRouter discovery
    ├── discovery-subagents.py     # Curated subagent-style discovery
    └── run-subagent-discovery.ps1 # Manual discovery runner
```

## 🚀 Development Workflow

1. **Load Environment:** Use `.\scr\set-env.ps1` (SecretStore-backed).
2. **Update Models (optional):** Use `.\scr\run-subagent-discovery.ps1` for curated refresh.
3. **Start Proxy:** `.\scr\start-proxy.ps1`.
4. **Verify:** Health check + model test calls.
5. **Document:** Update relevant `.md` files when behavior changes.

## ⚠️ Critical Rules

- **Never commit API keys:** Use SecretStore + `set-env.ps1`
- **Always verify config syntax:** Invalid YAML prevents startup
- **Check proxy health:** Before running complex tests, ensure `/health` returns 200 OK
- **Keep model list closed by default:** Avoid wildcard routes like `openrouter/*`
- **Discovery is opt-in:** Set `LITELLM_ENABLE_DISCOVERY=1` to enable startup discovery

## Completed

- [x] **Secret Externalization:**
  - Removed hardcoded secrets from scripts.
  - Added SecretStore setup and runtime loading.
- [x] **Path Hardening:**
  - Removed hardcoded machine paths in startup/discovery scripts.
  - Startup now derives config/script paths from repo layout.
- [x] **Closed OpenRouter Model List:**
  - Replaced wildcard and mixed-provider config with curated OpenRouter list.
  - Added stable aliases (`default`, `claude`, `reasoning`, `cheap`, etc.).
- [x] **Subagent Discovery (Separate File):**
  - Added `scr/discovery-subagents.py`.
  - Added `scr/run-subagent-discovery.ps1`.

## Coming up

- [ ] 1. Multi-Provider Orchestrator
  - [ ] Add provider subagents (OpenRouter, xAI, Gemini, Perplexity).
  - [ ] Normalize provider outputs into one model schema.
  - [ ] Write curated merged model list to `config.yaml`.
- [ ] 2. API Modernization
  - [ ] Audit scripts/tests still using chat completions style.
  - [ ] Migrate usage/tests where needed to Responses API flows.
- [ ] 3. Claude Code Integration
  - [ ] Add wrapper to load env and launch Claude Code consistently.
  - [ ] Finalize `config.json` integration path.
- [ ] 4. Reliability
  - [ ] Harden database checks and error handling for cost tracking views.
