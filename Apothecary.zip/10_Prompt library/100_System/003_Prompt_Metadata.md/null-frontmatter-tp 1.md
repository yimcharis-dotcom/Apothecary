---
Type: prompt
domain: <% tp.system.prompt("Domain (e.g. grammar, coding, legal)") %>
model_target: <% tp.system.prompt("Target model") %>
Status: draft
Version: 0.1
created: 2025-12-23 23:42
updated: 2025-12-23 23:42
Tags:
---
