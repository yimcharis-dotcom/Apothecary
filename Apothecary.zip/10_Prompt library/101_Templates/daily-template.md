---
type: daily
date: <% tp.file.title %>
created: <% tp.date.now("HH:mm") %>
tags: [daily]
---

[[<% tp.date.now("YYYY-MM-DD", -1, tp.file.title, "YYYY-MM-DD") %> | ⬅️ Yesterday]] | [[<% tp.date.now("YYYY-MM-DD", 1, tp.file.title, "YYYY-MM-DD") %> | ➡️ Tomorrow]]

# <% tp.date.now("dddd, YYYY-MM-DD", 0, tp.file.title, "YYYY-MM-DD") %>

## Tasks
- [ ] 
## Notes
- [ ]
## Reminder 
- [ ] 


