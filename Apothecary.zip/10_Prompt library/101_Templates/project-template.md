---
Type: project
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
Status: active
Priority: 
---

# <% tp.file.title %>

## Goal


## Requirements
- 
- 
- 

## Success Criteria
- 
- 

## Related Prompts
