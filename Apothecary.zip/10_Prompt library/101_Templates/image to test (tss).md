---
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
---

<% "#ocr #image-to-text" %>

## OCR Result

<% await tp.user.ocr(tp) %>
