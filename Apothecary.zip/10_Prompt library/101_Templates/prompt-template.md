---
Type: prompt
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
Domain:
Status: draft
Model:
Version: 1
---

# <% tp.file.title %>

## Purpose


## Prompt


## Example Input
