---
tags:
  - deployment/deployment-checklist
  - workflow-management
  - system-infrastructure
---

```
---
deployed-to: [[00_System/Prompts/Summarize_Text]]
---

[prompt content]

> **🔄 Deployment Status**  
> This prompt is deployed in System.  
> Last synced: 2026-01-04  
> To update deployed version: Copy → Paste to System file → Update plugin

```