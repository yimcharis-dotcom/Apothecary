---
tags:
  - workflow-management
  - system-infrastructure
  - templates
  - deployment/deployment-checklist
---

```
---
source: [[10_Prompt_library/System_Infrastructure/Summarize_Text]]
---

# ⚠️ DEPLOYED COPY - Edit source, then copy here

[prompt content - exact copy]

> **Source:** [[10_Prompt_library/System_Infrastructure/Summarize_Text]]  
> **Last synced:** 2026-01-04

```