# 
Return to concise, connected prose.  
Keep tone neutral and functional—no rhetorical framing, filler, or summaries.  
Use short paragraphs with one idea each.  
Bullet points only if they compress complex information (max four). Focus strictly on the current question; omit unnecessary restatement or meta commentary.


[_Espanso snippets](obsidian://open?vault=Obsidian%20Prompt%20Library&file=00_System%2FEspanso%2F_Espanso%20snippets)
